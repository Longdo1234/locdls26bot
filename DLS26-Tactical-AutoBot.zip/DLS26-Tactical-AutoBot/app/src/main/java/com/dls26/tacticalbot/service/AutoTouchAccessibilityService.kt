package com.dls26.tacticalbot.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.dls26.tacticalbot.config.BotConfig
import com.dls26.tacticalbot.config.BotRuntimeBus
import com.dls26.tacticalbot.model.ActionButton
import com.dls26.tacticalbot.model.BotAction
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Hard-Gated Multi-Touch Continuous Gesture Controller for DLS 26:
 * - STRICTLY refuses to call dispatchGesture() if:
 *     1) BotRuntimeBus.isBotRunning.get() == false
 *     2) BotRuntimeBus.isSettingsOpen.get() == true
 *     3) !isValidMinimap
 * - On Pause/Stop/SettingsOpen, immediately terminates any active continueStroke (willContinue = false)
 *   and purges all queued commands so joystick never drifts or sticks.
 * - Uses Landscape coordinates (screenWidth > screenHeight) clamped to [1f, W-1f] x [1f, H-1f].
 * - Chains continuous joystick strokes (50-80ms) via GestureResultCallback.onCompleted() and
 *   combines simultaneous A/B/C button strokes in the SAME GestureDescription (Multi-Touch).
 */
class AutoTouchAccessibilityService : AccessibilityService() {

    private data class PendingCommand(
        val action: BotAction,
        val config: BotConfig,
        val isValidMinimap: Boolean,
        val screenWidth: Int,
        val screenHeight: Int,
        val stepDurationMs: Long,
        val updatedAtMs: Long
    )

    private data class PendingButton(
        val button: ActionButton,
        val holdMs: Long,
        val queuedAtMs: Long
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private val isLoopRunning = AtomicBoolean(false)
    private val latestCommand = AtomicReference<PendingCommand?>(null)
    private val queuedButton = AtomicReference<PendingButton?>(null)

    private var activeJoystickStroke: GestureDescription.StrokeDescription? = null
    private var lastJoyX: Float = 1f
    private var lastJoyY: Float = 1f

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "AutoTouchAccessibilityService connected.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        stopAndReleaseJoystick()
    }

    override fun onDestroy() {
        stopAndReleaseJoystick()
        if (instance === this) {
            instance = null
        }
        super.onDestroy()
    }

    fun submitAction(
        action: BotAction,
        config: BotConfig,
        isValidMinimap: Boolean,
        screenWidth: Int,
        screenHeight: Int,
        frameIntervalMs: Long
    ) {
        // Hard Triple Safety Gate BEFORE queueing anything
        if (!BotRuntimeBus.isBotRunning.get() ||
            BotRuntimeBus.isSettingsOpen.get() ||
            !isValidMinimap
        ) {
            stopAndReleaseJoystick()
            return
        }

        val now = System.currentTimeMillis()
        val landscapeW = max(screenWidth, screenHeight)
        val landscapeH = min(screenWidth, screenHeight)

        latestCommand.set(
            PendingCommand(
                action = action,
                config = config,
                isValidMinimap = true,
                screenWidth = landscapeW,
                screenHeight = landscapeH,
                stepDurationMs = frameIntervalMs.coerceIn(50L, 80L),
                updatedAtMs = now
            )
        )

        if (action.button != ActionButton.NONE) {
            queuedButton.set(PendingButton(action.button, action.buttonHoldMs, now))
        }

        if (isLoopRunning.compareAndSet(false, true)) {
            mainHandler.post { dispatchNextChainedStep() }
        }
    }

    /**
     * Immediately halts gesture loop, clears all pending queues, and cleanly lifts any held joystick stroke.
     */
    fun stopAndReleaseJoystick() {
        latestCommand.set(null)
        queuedButton.set(null)
        mainHandler.post {
            releaseActiveStrokeAndStopLoop()
        }
    }

    private fun dispatchNextChainedStep() {
        val cmd = latestCommand.get()
        val now = System.currentTimeMillis()

        // Re-verify ALL safety gates right before calling dispatchGesture()
        if (!BotRuntimeBus.isBotRunning.get() ||
            BotRuntimeBus.isSettingsOpen.get() ||
            cmd == null ||
            !cmd.isValidMinimap ||
            (now - cmd.updatedAtMs) > 400L
        ) {
            releaseActiveStrokeAndStopLoop()
            return
        }

        val w = cmd.screenWidth.toFloat().coerceAtLeast(100f)
        val h = cmd.screenHeight.toFloat().coerceAtLeast(100f)
        val cfg = cmd.config
        val action = cmd.action

        val btnItem = queuedButton.getAndSet(null)?.takeIf { (now - it.queuedAtMs) <= 300L }
        val buttonHoldMs = btnItem?.holdMs?.coerceIn(50L, 380L) ?: 0L
        val stepMs = max(cmd.stepDurationMs, buttonHoldMs).coerceIn(50L, 380L)

        val builder = GestureDescription.Builder()
        var hasStroke = false

        // Stroke 1: Continuous Joystick Drag (willContinue = true)
        val joyCenterX = (cfg.joystickCenterX * w).coerceIn(1f, w - 1f)
        val joyCenterY = (cfg.joystickCenterY * h).coerceIn(1f, h - 1f)
        val joyRadius = cfg.joystickRadiusNorm * min(w, h)

        if (action.joystickActive) {
            val targetX = (joyCenterX + cos(action.joystickAngleRad) * joyRadius * action.joystickMagnitude)
                .coerceIn(1f, w - 1f)
            val targetY = (joyCenterY + sin(action.joystickAngleRad) * joyRadius * action.joystickMagnitude)
                .coerceIn(1f, h - 1f)

            val prev = activeJoystickStroke
            val path = Path()
            val nextStroke = if (prev == null) {
                path.moveTo(joyCenterX, joyCenterY)
                path.lineTo(targetX, targetY)
                GestureDescription.StrokeDescription(path, 0L, stepMs, true)
            } else {
                val startX = lastJoyX.coerceIn(1f, w - 1f)
                val startY = lastJoyY.coerceIn(1f, h - 1f)
                val midX = (startX + (targetX - startX) * 0.6f).coerceIn(1f, w - 1f)
                val midY = (startY + (targetY - startY) * 0.6f).coerceIn(1f, h - 1f)
                path.moveTo(startX, startY)
                path.quadTo(midX, midY, targetX, targetY)
                prev.continueStroke(path, 0L, stepMs, true)
            }

            activeJoystickStroke = nextStroke
            lastJoyX = targetX
            lastJoyY = targetY
            builder.addStroke(nextStroke)
            hasStroke = true
        } else if (activeJoystickStroke != null) {
            val releasePath = Path().apply {
                moveTo(lastJoyX.coerceIn(1f, w - 1f), lastJoyY.coerceIn(1f, h - 1f))
                lineTo(joyCenterX, joyCenterY)
            }
            val endStroke = activeJoystickStroke!!.continueStroke(releasePath, 0L, 40L, false)
            activeJoystickStroke = null
            builder.addStroke(endStroke)
            hasStroke = true
        }

        // Stroke 2: Simultaneous Multi-Touch Action Button (A/B/C)
        if (btnItem != null && btnItem.button != ActionButton.NONE && btnItem.button != ActionButton.MENU_CONTINUE) {
            val (bxNorm, byNorm) = when (btnItem.button) {
                ActionButton.A_SHOOT_OR_TACKLE -> cfg.buttonAX to cfg.buttonAY
                ActionButton.B_LOW_PASS_OR_PRESS -> cfg.buttonBX to cfg.buttonBY
                ActionButton.C_LOFTED_PASS_OR_SWITCH -> cfg.buttonCX to cfg.buttonCY
                else -> 0.5f to 0.5f
            }
            val bx = (bxNorm * w).coerceIn(1f, w - 1f)
            val by = (byNorm * h).coerceIn(1f, h - 1f)
            val bxEnd = (bx + 1f).coerceIn(1f, w - 1f)
            val byEnd = (by + 1f).coerceIn(1f, h - 1f)

            val btnPath = Path().apply {
                moveTo(bx, by)
                lineTo(bxEnd, byEnd)
            }
            val btnStroke = GestureDescription.StrokeDescription(btnPath, 0L, buttonHoldMs, false)
            builder.addStroke(btnStroke)
            hasStroke = true
        }

        if (!hasStroke) {
            isLoopRunning.set(false)
            return
        }

        try {
            val dispatched = dispatchGesture(
                builder.build(),
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (isLoopRunning.get() &&
                            BotRuntimeBus.isBotRunning.get() &&
                            !BotRuntimeBus.isSettingsOpen.get()
                        ) {
                            mainHandler.post { dispatchNextChainedStep() }
                        } else {
                            mainHandler.post { releaseActiveStrokeAndStopLoop() }
                        }
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        activeJoystickStroke = null
                        if (isLoopRunning.get() &&
                            BotRuntimeBus.isBotRunning.get() &&
                            !BotRuntimeBus.isSettingsOpen.get()
                        ) {
                            mainHandler.postDelayed({ dispatchNextChainedStep() }, 45L)
                        } else {
                            isLoopRunning.set(false)
                        }
                    }
                },
                mainHandler
            )
            if (!dispatched) {
                activeJoystickStroke = null
                isLoopRunning.set(false)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Multi-touch dispatchGesture error: ${e.message}")
            activeJoystickStroke = null
            isLoopRunning.set(false)
        }
    }

    private fun releaseActiveStrokeAndStopLoop() {
        val stroke = activeJoystickStroke
        activeJoystickStroke = null
        if (stroke != null) {
            try {
                val path = Path().apply {
                    moveTo(lastJoyX, lastJoyY)
                    lineTo(lastJoyX, lastJoyY)
                }
                val endStroke = stroke.continueStroke(path, 0L, 35L, false)
                dispatchGesture(GestureDescription.Builder().addStroke(endStroke).build(), null, null)
            } catch (_: Exception) {
                // Safe ignore
            }
        }
        isLoopRunning.set(false)
    }

    companion object {
        private const val TAG = "AutoTouchService"

        @Volatile
        var instance: AutoTouchAccessibilityService? = null
            private set

        fun isConnected(): Boolean = instance != null
    }
}
