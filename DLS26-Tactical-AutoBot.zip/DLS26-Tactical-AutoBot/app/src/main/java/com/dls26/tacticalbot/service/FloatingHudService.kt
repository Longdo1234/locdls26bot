package com.dls26.tacticalbot.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.dls26.tacticalbot.config.BotConfig
import com.dls26.tacticalbot.config.BotConfigStore
import com.dls26.tacticalbot.config.BotRuntimeBus
import com.dls26.tacticalbot.model.BotAction
import com.dls26.tacticalbot.model.GameState
import com.dls26.tacticalbot.ui.DebugOverlayView
import com.dls26.tacticalbot.ui.FloatingControlView
import com.dls26.tacticalbot.ui.InHudSettingsOverlay
import com.dls26.tacticalbot.ui.RoiCalibrationOverlay

class FloatingHudService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var configStore: BotConfigStore
    private val mainHandler = Handler(Looper.getMainLooper())

    private var debugOverlayView: DebugOverlayView? = null
    private var floatingControlView: FloatingControlView? = null
    private var settingsOverlayView: InHudSettingsOverlay? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        configStore = BotConfigStore(this)
        BotRuntimeBus.updateConfig(configStore.load())
        // Always start paused & settings closed
        BotRuntimeBus.setBotActive(false)
        BotRuntimeBus.setSettingsOpen(false)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (Settings.canDrawOverlays(this)) {
            mainHandler.post {
                attachDebugOverlay()
                attachFloatingHudPill()
            }
        }
        return START_NOT_STICKY
    }

    fun updateDebugFrame(state: GameState, action: BotAction, config: BotConfig, active: Boolean) {
        mainHandler.post {
            val view = debugOverlayView ?: return@post
            view.visibility = if (config.debugOverlayEnabled) View.VISIBLE else View.GONE
            if (config.debugOverlayEnabled) {
                view.updateDebugData(state, action, config, active)
            }
        }
    }

    private fun attachDebugOverlay() {
        if (debugOverlayView != null) return
        val overlay = DebugOverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(overlay, params)
        overlay.visibility = if (BotRuntimeBus.config.value.debugOverlayEnabled) View.VISIBLE else View.GONE
        debugOverlayView = overlay
    }

    private fun attachFloatingHudPill() {
        if (floatingControlView != null) return
        val pillParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 104
        }

        val pill = FloatingControlView(
            context = this,
            onTogglePlay = {
                val nextActive = !BotRuntimeBus.isBotRunning.get()
                BotRuntimeBus.setBotActive(nextActive)
                if (!nextActive) {
                    AutoTouchAccessibilityService.instance?.stopAndReleaseJoystick()
                }
            },
            onOpenSettings = { toggleInHudSettings() },
            onStopService = {
                BotRuntimeBus.setBotActive(false)
                BotRuntimeBus.setSettingsOpen(false)
                AutoTouchAccessibilityService.instance?.stopAndReleaseJoystick()
                stopService(Intent(this, ScreenCaptureService::class.java))
                stopSelf()
            },
            onDragBy = { dx, dy ->
                pillParams.x += dx
                pillParams.y += dy
                runCatching { windowManager.updateViewLayout(floatingControlView, pillParams) }
            }
        )
        pill.updatePlayVisual(false)
        windowManager.addView(pill, pillParams)
        floatingControlView = pill
    }

    private fun toggleInHudSettings() {
        if (settingsOverlayView != null) {
            closeInHudSettings()
            return
        }

        // Immediately block gestures & release joystick while Settings overlay is open
        BotRuntimeBus.setSettingsOpen(true)
        AutoTouchAccessibilityService.instance?.stopAndReleaseJoystick()

        val panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = 0
            y = 0
        }

        val panel = InHudSettingsOverlay(
            context = this,
            initialConfig = BotRuntimeBus.config.value,
            onConfigChanged = { updated ->
                configStore.save(updated)
                BotRuntimeBus.updateConfig(updated)
                debugOverlayView?.visibility = if (updated.debugOverlayEnabled) View.VISIBLE else View.GONE
            },
            onOpenAnchorCalibration = {
                // Keep isSettingsOpen = true during Anchor Drag Calibration
                BotRuntimeBus.setSettingsOpen(true)
                AutoTouchAccessibilityService.instance?.stopAndReleaseJoystick()
                RoiCalibrationOverlay.show(
                    context = this,
                    windowManager = windowManager,
                    initialConfig = BotRuntimeBus.config.value,
                    onSaved = { calibrated ->
                        configStore.save(calibrated)
                        BotRuntimeBus.updateConfig(calibrated)
                        BotRuntimeBus.setSettingsOpen(false)
                    },
                    onDismissed = {
                        BotRuntimeBus.setSettingsOpen(false)
                    }
                )
            },
            onClose = { closeInHudSettings() },
            onDragBy = { dx, dy ->
                panelParams.x += dx
                panelParams.y += dy
                runCatching { windowManager.updateViewLayout(settingsOverlayView, panelParams) }
            }
        )
        windowManager.addView(panel, panelParams)
        settingsOverlayView = panel
    }

    private fun closeInHudSettings() {
        settingsOverlayView?.let { runCatching { windowManager.removeView(it) } }
        settingsOverlayView = null
        BotRuntimeBus.setSettingsOpen(false)
    }

    override fun onDestroy() {
        BotRuntimeBus.setBotActive(false)
        BotRuntimeBus.setSettingsOpen(false)
        AutoTouchAccessibilityService.instance?.stopAndReleaseJoystick()
        mainHandler.post {
            closeInHudSettings()
            debugOverlayView?.let { runCatching { windowManager.removeView(it) } }
            debugOverlayView = null
            floatingControlView?.let { runCatching { windowManager.removeView(it) } }
            floatingControlView = null
        }
        if (instance === this) {
            instance = null
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.dls26.tacticalbot.FLOATING_HUD_STOP"

        @Volatile
        var instance: FloatingHudService? = null
            private set
    }
}
