package com.dlsbot.app

import android.graphics.PointF
import android.graphics.Rect
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.roundToInt

data class MinimapSnapshot(
    val timestampMs: Long,
    val allies: List<PointF>,       // X in [-1, 1], Y in [-1, 1] (+1 = khung thành đối thủ)
    val opponents: List<PointF>,    // X in [-1, 1], Y in [-1, 1]
    val ball: PointF?,              // X in [-1, 1], Y in [-1, 1]
    val attackingUp: Boolean,       // true: nhà ở dưới (y_raw > 0.82), tấn công lên trên (y_raw -> 0)
    val scanLatencyMs: Long
)

object BotRuntimeState {
    @Volatile var isRunning: Boolean = false
    @Volatile var isHudOverlayBusy: Boolean = false
    @Volatile var manualInvertVertical: Boolean = false
    @Volatile var joystickRotationDeg: Int = 0 // 0, 90, -90
    @Volatile var minimapRect: Rect = Rect(900, 120, 1060, 440) // Mặc định Minimap dọc

    // Tọa độ nút DLS 26
    @Volatile var joyCenter: PointF = PointF(300f, 820f)
    @Volatile var joyRadius: Float = 150f
    @Volatile var btnA: PointF = PointF(2080f, 760f) // Sút / Xoạc
    @Volatile var btnB: PointF = PointF(1920f, 900f) // Chuyền thấp / Áp sát
    @Volatile var btnC: PointF = PointF(1920f, 640f) // Chuyền bổng / Tạt cánh / Đổi người

    fun canDispatchTouch(): Boolean {
        return isRunning && !isHudOverlayBusy
    }
}

class MinimapScanner {

    companion object {
        private const val MAX_SCALED_DIM = 180.0
        private const val CONFIRM_FRAMES_REQUIRED = 15
        private const val GK_BOTTOM_THRESHOLD = 0.82f
        private const val GK_TOP_THRESHOLD = 0.18f
        private const val MIN_CONTOUR_AREA = 6.0
        private const val MAX_CONTOUR_AREA = 450.0
    }

    // Zero-Allocation: Pre-allocate toàn bộ Mat dùng lại qua các frame
    private val resizedMat = Mat()
    private val rgbMat = Mat()
    private val hsvMat = Mat()
    private val maskRed1 = Mat()
    private val maskRed2 = Mat()
    private val maskRed = Mat()
    private val maskWhite = Mat()
    private val maskField = Mat()
    private val maskNonField = Mat()
    private val maskTemp = Mat()
    private val maskOpp = Mat()
    private val hierarchy = Mat()
    private val kernel3x3 = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(3.0, 3.0))

    // Ngưỡng HSV cho Minimap DLS 26
    private val redLow1 = Scalar(0.0, 120.0, 90.0)
    private val redHigh1 = Scalar(10.0, 255.0, 255.0)
    private val redLow2 = Scalar(165.0, 120.0, 90.0)
    private val redHigh2 = Scalar(180.0, 255.0, 255.0)

    private val whiteLow = Scalar(0.0, 0.0, 200.0)
    private val whiteHigh = Scalar(180.0, 55.0, 255.0)

    // Mặt cỏ xanh lá để loại trừ khi tìm đối thủ (màu còn lại)
    private val fieldLow = Scalar(32.0, 45.0, 40.0)
    private val fieldHigh = Scalar(90.0, 255.0, 220.0)

    // Bộ đếm xác nhận hướng tấn công dọc
    private var confirmedAttackingUp: Boolean = true
    private var candidateAttackingUp: Boolean = true
    private var confirmFrameCount: Int = 0

    private val contoursBuffer = ArrayList<MatOfPoint>(32)

    fun scan(fullRgbaFrame: Mat, roiRect: Rect): MinimapSnapshot {
        val startNs = System.nanoTime()

        // 1. Clamp ROI an toàn trong kích thước ảnh gốc
        val safeLeft = roiRect.left.coerceIn(0, max(0, fullRgbaFrame.cols() - 2))
        val safeTop = roiRect.top.coerceIn(0, max(0, fullRgbaFrame.rows() - 2))
        val safeRight = roiRect.right.coerceIn(safeLeft + 1, fullRgbaFrame.cols())
        val safeBottom = roiRect.bottom.coerceIn(safeTop + 1, fullRgbaFrame.rows())
        val cvRect = org.opencv.core.Rect(safeLeft, safeTop, safeRight - safeLeft, safeBottom - safeTop)

        // 2. Crop ROI trực tiếp (không copy) -> Resize <= 180px -> Convert HSV
        val roiView = fullRgbaFrame.submat(cvRect)
        try {
            val maxDim = max(roiView.cols(), roiView.rows()).toDouble()
            val scale = if (maxDim > MAX_SCALED_DIM) MAX_SCALED_DIM / maxDim else 1.0
            val targetW = max(1, (roiView.cols() * scale).roundToInt()).toDouble()
            val targetH = max(1, (roiView.rows() * scale).roundToInt()).toDouble()

            Imgproc.resize(roiView, resizedMat, Size(targetW, targetH), 0.0, 0.0, Imgproc.INTER_LINEAR)
            Imgproc.cvtColor(resizedMat, rgbMat, Imgproc.COLOR_RGBA2RGB)
            Imgproc.cvtColor(rgbMat, hsvMat, Imgproc.COLOR_RGB2HSV)
        } finally {
            roiView.release()
        }

        val w = hsvMat.cols().toFloat()
        val h = hsvMat.rows().toFloat()

        // 3. Tách mask Đỏ (đội mình)
        Core.inRange(hsvMat, redLow1, redHigh1, maskRed1)
        Core.inRange(hsvMat, redLow2, redHigh2, maskRed2)
        Core.bitwise_or(maskRed1, maskRed2, maskRed)
        Imgproc.morphologyEx(maskRed, maskRed, Imgproc.MORPH_OPEN, kernel3x3)

        // 4. Tách mask Trắng (bóng)
        Core.inRange(hsvMat, whiteLow, whiteHigh, maskWhite)
        Imgproc.morphologyEx(maskWhite, maskWhite, Imgproc.MORPH_OPEN, kernel3x3)

        // 5. Tách mask Đối thủ (màu còn lại: không phải cỏ, không phải đỏ, không phải trắng)
        Core.inRange(hsvMat, fieldLow, fieldHigh, maskField)
        Core.bitwise_not(maskField, maskNonField)
        Core.bitwise_or(maskRed, maskWhite, maskTemp)
        Core.bitwise_not(maskTemp, maskTemp)
        Core.bitwise_and(maskNonField, maskTemp, maskOpp)
        Imgproc.morphologyEx(maskOpp, maskOpp, Imgproc.MORPH_OPEN, kernel3x3)

        // 6. Trích xuất tọa độ thô [0..1]
        val rawAllies = extractCentroids(maskRed, w, h, maxPoints = 11)
        val rawBallList = extractCentroids(maskWhite, w, h, maxPoints = 3, preferSmallestRound = true)
        val rawOpponents = extractCentroids(maskOpp, w, h, maxPoints = 11)

        // 7. Xác định hướng tấn công dọc dựa vào Thủ môn áo đỏ (confirmFrames >= 15)
        updateVerticalDirection(rawAllies)
        val effectiveAttackingUp = if (BotRuntimeState.manualInvertVertical) {
            !confirmedAttackingUp
        } else {
            confirmedAttackingUp
        }

        // 8. Chuẩn hóa sang hệ tọa độ dọc: X in [-1, +1], Y in [-1, +1] (+1 = khung thành đối thủ)
        val normAllies = rawAllies.map { normalizeVertical(it, effectiveAttackingUp) }
        val normOpponents = rawOpponents.map { normalizeVertical(it, effectiveAttackingUp) }
        val normBall = rawBallList.firstOrNull()?.let { normalizeVertical(it, effectiveAttackingUp) }

        val latencyMs = (System.nanoTime() - startNs) / 1_000_000L
        return MinimapSnapshot(
            timestampMs = System.currentTimeMillis(),
            allies = normAllies,
            opponents = normOpponents,
            ball = normBall,
            attackingUp = effectiveAttackingUp,
            scanLatencyMs = latencyMs
        )
    }

    private fun updateVerticalDirection(rawAllies: List<PointF>) {
        if (rawAllies.isEmpty()) return

        var hasBottomGk = false
        var hasTopGk = false
        for (p in rawAllies) {
            if (p.y > GK_BOTTOM_THRESHOLD) hasBottomGk = true
            if (p.y < GK_TOP_THRESHOLD) hasTopGk = true
        }

        val detectedUp: Boolean? = when {
            hasBottomGk && !hasTopGk -> true   // Thủ môn ở dưới -> Tấn công lên trên
            hasTopGk && !hasBottomGk -> false  // Thủ môn ở trên -> Tấn công xuống dưới
            else -> null
        }

        if (detectedUp != null) {
            if (detectedUp == candidateAttackingUp) {
                confirmFrameCount++
                if (confirmFrameCount >= CONFIRM_FRAMES_REQUIRED) {
                    confirmedAttackingUp = candidateAttackingUp
                }
            } else {
                candidateAttackingUp = detectedUp
                confirmFrameCount = 1
            }
        }
    }

    private fun normalizeVertical(raw: PointF, attackingUp: Boolean): PointF {
        val normX = (raw.x * 2f - 1f).coerceIn(-1f, 1f)
        val normY = if (attackingUp) {
            (1f - raw.y * 2f).coerceIn(-1f, 1f)
        } else {
            (raw.y * 2f - 1f).coerceIn(-1f, 1f)
        }
        return PointF(normX, normY)
    }

    private fun extractCentroids(
        mask: Mat,
        width: Float,
        height: Float,
        maxPoints: Int,
        preferSmallestRound: Boolean = false
    ): List<PointF> {
        contoursBuffer.clear()
        Imgproc.findContours(mask, contoursBuffer, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

        val candidates = ArrayList<Pair<Double, PointF>>(contoursBuffer.size)
        for (contour in contoursBuffer) {
            val area = Imgproc.contourArea(contour)
            if (area in MIN_CONTOUR_AREA..MAX_CONTOUR_AREA) {
                val m = Imgproc.moments(contour)
                if (m.m00 > 0.0) {
                    val cx = (m.m10 / m.m00).toFloat() / width
                    val cy = (m.m01 / m.m00).toFloat() / height
                    candidates.add(area to PointF(cx, cy))
                }
            }
            contour.release()
        }
        contoursBuffer.clear()

        if (preferSmallestRound) {
            candidates.sortBy { it.first }
        } else {
            candidates.sortByDescending { it.first }
        }

        return candidates.take(maxPoints).map { it.second }
    }

    fun release() {
        resizedMat.release()
        rgbMat.release()
        hsvMat.release()
        maskRed1.release()
        maskRed2.release()
        maskRed.release()
        maskWhite.release()
        maskField.release()
        maskNonField.release()
        maskTemp.release()
        maskOpp.release()
        hierarchy.release()
        kernel3x3.release()
    }
}
