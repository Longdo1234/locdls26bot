package com.dlsbot.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingHudService : Service() {

    private lateinit var windowManager: WindowManager
    private var hudLayout: LinearLayout? = null
    private var settingsLayout: LinearLayout? = null
    private var debugOverlayView: DebugOverlayView? = null

    private lateinit var btnRunToggle: Button
    private lateinit var btnInvertDir: Button
    private lateinit var btnJoyRotation: Button

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        setupDebugOverlay()
        setupFloatingHud()
    }

    private fun setupDebugOverlay() {
        debugOverlayView = DebugOverlayView(this)
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(debugOverlayView, params)

        ScreenCaptureService.debugOverlayCallback = { snapshot, command ->
            debugOverlayView?.updateDebugData(snapshot, command)
        }
    }

    private fun setupFloatingHud() {
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        hudLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.argb(200, 20, 20, 30))
            setPadding(16, 12, 16, 12)
        }

        btnRunToggle = Button(this).apply {
            text = "RUN"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#16A34A"))
            setOnClickListener {
                BotRuntimeState.isRunning = !BotRuntimeState.isRunning
                updateRunButtonUi()
                if (!BotRuntimeState.isRunning) {
                    AutoTouchAccessibilityService.instance?.releaseJoystickImmediately()
                }
            }
        }

        val btnSettings = Button(this).apply {
            text = "⚙ Cài đặt"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#334155"))
            setOnClickListener { toggleSettingsPanel() }
        }

        hudLayout!!.addView(btnRunToggle)
        hudLayout!!.addView(btnSettings)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 80
        }

        windowManager.addView(hudLayout, params)
    }

    private fun toggleSettingsPanel() {
        if (settingsLayout != null) {
            closeSettingsPanel()
            return
        }

        BotRuntimeState.isHudOverlayBusy = true
        AutoTouchAccessibilityService.instance?.releaseJoystickImmediately()

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        settingsLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(235, 15, 23, 42))
            setPadding(28, 24, 28, 24)
        }

        val title = TextView(this).apply {
            text = "CÀI ĐẶT BOT DLS 26 (MINIMAP DỌC)"
            setTextColor(Color.CYAN)
            textSize = 15f
            setPadding(0, 0, 0, 16)
        }

        btnInvertDir = Button(this).apply {
            updateInvertButtonText(this)
            setOnClickListener {
                BotRuntimeState.manualInvertVertical = !BotRuntimeState.manualInvertVertical
                updateInvertButtonText(this)
            }
        }

        btnJoyRotation = Button(this).apply {
            updateRotationButtonText(this)
            setOnClickListener {
                BotRuntimeState.joystickRotationDeg = when (BotRuntimeState.joystickRotationDeg) {
                    0 -> 90
                    90 -> -90
                    else -> 0
                }
                updateRotationButtonText(this)
            }
        }

        val btnClose = Button(this).apply {
            text = "Đóng & Lưu"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#0284C7"))
            setOnClickListener { closeSettingsPanel() }
        }

        settingsLayout!!.addView(title)
        settingsLayout!!.addView(btnInvertDir)
        settingsLayout!!.addView(btnJoyRotation)
        settingsLayout!!.addView(btnClose)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        windowManager.addView(settingsLayout, params)
    }

    private fun closeSettingsPanel() {
        settingsLayout?.let { windowManager.removeView(it) }
        settingsLayout = null
        BotRuntimeState.isHudOverlayBusy = false
    }

    private fun updateRunButtonUi() {
        if (BotRuntimeState.isRunning) {
            btnRunToggle.text = "STOP"
            btnRunToggle.setBackgroundColor(Color.parseColor("#DC2626"))
        } else {
            btnRunToggle.text = "RUN"
            btnRunToggle.setBackgroundColor(Color.parseColor("#16A34A"))
        }
    }

    private fun updateInvertButtonText(btn: Button) {
        val state = if (BotRuntimeState.manualInvertVertical) "BẬT (Đảo ngược)" else "TẮT (Tự động)"
        btn.text = "Đảo trục dọc thủ công: $state"
    }

    private fun updateRotationButtonText(btn: Button) {
        btn.text = "Xoay góc Joystick: ${BotRuntimeState.joystickRotationDeg}°"
    }

    override fun onDestroy() {
        super.onDestroy()
        ScreenCaptureService.debugOverlayCallback = null
        closeSettingsPanel()
        hudLayout?.let { windowManager.removeView(it) }
        debugOverlayView?.let { windowManager.removeView(it) }
        BotRuntimeState.isRunning = false
        AutoTouchAccessibilityService.instance?.releaseJoystickImmediately()
    }
}
