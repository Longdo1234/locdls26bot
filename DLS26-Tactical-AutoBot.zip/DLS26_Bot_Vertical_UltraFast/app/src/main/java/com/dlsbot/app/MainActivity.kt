package com.dlsbot.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.opencv.android.OpenCVLoader

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)

            val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                putExtra(ScreenCaptureService.EXTRA_WIDTH, metrics.widthPixels)
                putExtra(ScreenCaptureService.EXTRA_HEIGHT, metrics.heightPixels)
                putExtra(ScreenCaptureService.EXTRA_DENSITY, metrics.densityDpi)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(captureIntent)
            } else {
                startService(captureIntent)
            }

            startService(Intent(this, FloatingHudService::class.java))
            statusText.text = "Trạng thái: Đã bật Vision + HUD nổi (Chưa RUN)"
            Toast.makeText(this, "Đã khởi động HUD nổi! Vào DLS 26 rồi bấm RUN.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Bạn chưa cấp quyền quay màn hình!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val cvOk = OpenCVLoader.initLocal()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#0F172A"))
            setPadding(48, 72, 48, 48)
        }

        val title = TextView(this).apply {
            text = "DLS 26 BOT - MINIMAP DỌC"
            textSize = 22f
            setTextColor(Color.parseColor("#38BDF8"))
            setPadding(0, 0, 0, 16)
        }

        statusText = TextView(this).apply {
            text = if (cvOk) "OpenCV 4.9.0: Sẵn sàng" else "OpenCV: Lỗi khởi tạo!"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 40)
        }

        val btnOverlay = createStyledButton("1. Cấp quyền Hiển thị trên ứng dụng khác", "#334155") {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Đã có quyền Overlay!", Toast.LENGTH_SHORT).show()
            }
        }

        val btnAccessibility = createStyledButton("2. Bật Accessibility (AutoTouch)", "#334155") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val btnStart = createStyledButton("3. Khởi động Bot & HUD nổi", "#16A34A") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Hãy cấp quyền Overlay ở bước 1 trước!", Toast.LENGTH_SHORT).show()
                return@createStyledButton
            }
            if (AutoTouchAccessibilityService.instance == null) {
                Toast.makeText(this, "Hãy bật DLS 26 AutoTouch ở bước 2 trước!", Toast.LENGTH_SHORT).show()
                return@createStyledButton
            }
            val pm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(pm.createScreenCaptureIntent())
        }

        val btnStop = createStyledButton("4. Dừng toàn bộ Bot", "#DC2626") {
            BotRuntimeState.isRunning = false
            AutoTouchAccessibilityService.instance?.releaseJoystickImmediately()
            stopService(Intent(this, FloatingHudService::class.java))
            stopService(Intent(this, ScreenCaptureService::class.java))
            statusText.text = "Trạng thái: Đã dừng Bot"
        }

        root.addView(title)
        root.addView(statusText)
        root.addView(btnOverlay)
        root.addView(btnAccessibility)
        root.addView(btnStart)
        root.addView(btnStop)

        setContentView(root)
    }

    private fun createStyledButton(label: String, colorHex: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor(colorHex))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 24)
            }
            layoutParams = lp
            setPadding(24, 32, 24, 32)
            setOnClickListener { onClick() }
        }
    }
}
