package com.dlsbot.app

import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

enum class ActionButton {
    NONE, A_SHOOT_TACKLE, B_LOW_PASS_PRESS, C_CROSS_SWITCH
}

data class TacticalCommand(
    val hasDirection: Boolean,
    val moveDx: Float,              // Vector hướng trong hệ Minimap dọc [-1..1]
    val moveDy: Float,              // +1 = hướng thẳng lên khung thành đối thủ
    val actionButton: ActionButton = ActionButton.NONE,
    val holdDurationMs: Long = 0L,
    val label: String = "IDLE"
)

class TacticalDecisionEngine {

    companion object {
        private const val SHOOT_COOLDOWN_MS = 850L
        private const val PASS_COOLDOWN_MS = 950L
        private const val POSSESSION_RADIUS = 0.14f
    }

    private var lastShootTimeMs: Long = 0L
    private var lastPassTimeMs: Long = 0L

    // Trạng thái rê dắt né đối thủ
    private var dribbleUntilMs: Long = 0L
    private var dribbleAngleOffsetRad: Float = 0f

    fun decide(snapshot: MinimapSnapshot): TacticalCommand {
        val ball = snapshot.ball ?: return TacticalCommand(false, 0f, 0f, label = "NO_BALL")
        val now = snapshot.timestampMs

        val nearestAlly = findNearest(ball, snapshot.allies)
        val nearestOpp = findNearest(ball, snapshot.opponents)

        val allyBallDist = nearestAlly?.let { dist(it, ball) } ?: Float.MAX_VALUE
        val oppBallDist = nearestOpp?.let { dist(it, ball) } ?: Float.MAX_VALUE

        val weHaveBall = nearestAlly != null && allyBallDist <= POSSESSION_RADIUS && allyBallDist <= oppBallDist + 0.03f

        if (!weHaveBall) {
            return decideDefenseOrChase(ball, nearestAlly, snapshot.opponents)
        }

        val player = nearestAlly!!
        val playerX = player.x
        val playerY = player.y

        // ƯU TIÊN 1: BỨT TỐC VÀO GẦN VÒNG CẤM & NGẮM THẲNG KHUNG THÀNH SÚT (A)
        if (playerY >= 0.50f && abs(playerX) <= 0.52f) {
            val frontOpp = findNearestFrontOpponent(player, snapshot.opponents, maxDist = 0.20f)
            val inShootRange = (playerY >= 0.60f && abs(playerX) <= 0.50f) ||
                (playerY >= 0.52f && frontOpp != null && dist(player, frontOpp) < 0.16f)

            val aimDx = 0.0f - playerX
            val aimDy = 1.0f - playerY

            if (inShootRange && now - lastShootTimeMs >= SHOOT_COOLDOWN_MS) {
                lastShootTimeMs = now
                val holdMs = Random.nextLong(220L, 321L)
                return TacticalCommand(
                    hasDirection = true,
                    moveDx = aimDx,
                    moveDy = aimDy,
                    actionButton = ActionButton.A_SHOOT_TACKLE,
                    holdDurationMs = holdMs,
                    label = "SHOOT_STRAIGHT (A)"
                )
            }

            if (playerY < 0.65f && frontOpp == null) {
                return TacticalCommand(
                    hasDirection = true,
                    moveDx = aimDx,
                    moveDy = aimDy,
                    label = "SPRINT_INTO_BOX"
                )
            }
        }

        // ƯU TIÊN 2: XỬ LÝ KHI ĐÃ RA CÁNH (|playerX| >= 0.52 && playerY >= 0.45)
        if (abs(playerX) >= 0.52f && playerY >= 0.45f) {
            val boxAlly = snapshot.allies
                .filter { it !== player && abs(it.x) <= 0.42f && it.y >= 0.55f }
                .maxByOrNull { it.y }

            if (boxAlly != null && now - lastPassTimeMs >= PASS_COOLDOWN_MS) {
                val targetX = boxAlly.x
                val targetY = (boxAlly.y + 0.07f).coerceAtMost(0.98f)
                val passDx = targetX - playerX
                val passDy = targetY - playerY

                val groundBlocked = isPassLineBlocked(player, PointF(targetX, targetY), snapshot.opponents, 0.10f)
                lastPassTimeMs = now

                return if (groundBlocked) {
                    TacticalCommand(
                        hasDirection = true,
                        moveDx = passDx,
                        moveDy = passDy,
                        actionButton = ActionButton.C_CROSS_SWITCH,
                        holdDurationMs = Random.nextLong(220L, 301L),
                        label = "WING_CROSS (C)"
                    )
                } else {
                    TacticalCommand(
                        hasDirection = true,
                        moveDx = passDx,
                        moveDy = passDy,
                        actionButton = ActionButton.B_LOW_PASS_PRESS,
                        holdDurationMs = Random.nextLong(180L, 241L),
                        label = "WING_CUTBACK (B)"
                    )
                }
            }

            val nearestFrontOppDist = findNearestFrontOpponent(player, snapshot.opponents, 0.50f)
                ?.let { dist(player, it) } ?: Float.MAX_VALUE
            if (nearestFrontOppDist > 0.16f && playerY < 0.80f) {
                return TacticalCommand(
                    hasDirection = true,
                    moveDx = 0f,
                    moveDy = 1f,
                    label = "WING_SPRINT_UP"
                )
            }
        }

        // ƯU TIÊN 3: CHỈ CHUYỀN LÊN & CHUYỀN FULL LỰC RA CÁNH (CẤM CHUYỀN NGƯỢC)
        if (now - lastPassTimeMs >= PASS_COOLDOWN_MS) {
            if (playerY < 0.55f) {
                val openWinger = snapshot.allies
                    .filter { ally ->
                        ally !== player &&
                            abs(ally.x) >= 0.52f &&
                            ally.y > playerY + 0.15f &&
                            isUnmarked(ally, snapshot.opponents, radius = 0.14f)
                    }
                    .maxByOrNull { it.y }

                if (openWinger != null) {
                    val passDx = openWinger.x - playerX
                    val passDy = (openWinger.y + 0.05f).coerceAtMost(0.95f) - playerY
                    val groundBlocked = isPassLineBlocked(player, openWinger, snapshot.opponents, 0.10f)
                    lastPassTimeMs = now

                    return if (groundBlocked) {
                        TacticalCommand(
                            hasDirection = true,
                            moveDx = passDx,
                            moveDy = passDy,
                            actionButton = ActionButton.C_CROSS_SWITCH,
                            holdDurationMs = Random.nextLong(340L, 441L),
                            label = "FULL_POWER_WING_C"
                        )
                    } else {
                        TacticalCommand(
                            hasDirection = true,
                            moveDx = passDx,
                            moveDy = passDy,
                            actionButton = ActionButton.B_LOW_PASS_PRESS,
                            holdDurationMs = Random.nextLong(280L, 361L),
                            label = "FULL_POWER_WING_B"
                        )
                    }
                }
            }

            val pressedHard = snapshot.opponents.any { dist(player, it) < 0.13f }
            if (pressedHard) {
                val forwardAlly = snapshot.allies
                    .filter { ally ->
                        ally !== player &&
                            ally.y > playerY + 0.08f &&
                            !isPassLineBlocked(player, ally, snapshot.opponents, 0.09f)
                    }
                    .minByOrNull { dist(player, it) }

                if (forwardAlly != null) {
                    lastPassTimeMs = now
                    return TacticalCommand(
                        hasDirection = true,
                        moveDx = forwardAlly.x - playerX,
                        moveDy = forwardAlly.y - playerY,
                        actionButton = ActionButton.B_LOW_PASS_PRESS,
                        holdDurationMs = Random.nextLong(140L, 221L),
                        label = "FORWARD_PASS (B)"
                    )
                }
            }
        }

        // ƯU TIÊN 4: RÊ DẮT QUA NGƯỜI & BỨT TỐC THẲNG LÊN SÂN ĐỐI PHƯƠNG
        val baseDx = (playerX * 0.6f) - playerX
        val baseDy = 1.0f - playerY

        if (now < dribbleUntilMs) {
            val baseAngle = atan2(baseDy, baseDx)
            val evasiveAngle = baseAngle + dribbleAngleOffsetRad
            return TacticalCommand(
                hasDirection = true,
                moveDx = cos(evasiveAngle),
                moveDy = sin(evasiveAngle),
                label = "DRIBBLE_EVADE"
            )
        }

        val blockingOpp = snapshot.opponents
            .filter { opp ->
                opp.y > playerY &&
                    dist(player, opp) < 0.22f &&
                    abs(opp.x - playerX) < 0.14f
            }
            .minByOrNull { dist(player, it) }

        if (blockingOpp != null) {
            val leftSpaceScore = evaluateSideSpace(player, snapshot.opponents, goRight = false)
            val rightSpaceScore = evaluateSideSpace(player, snapshot.opponents, goRight = true)
            val dodgeAngleDeg = Random.nextFloat() * 13f + 35f // 35° – 48°
            val dodgeRad = Math.toRadians(dodgeAngleDeg.toDouble()).toFloat()

            dribbleAngleOffsetRad = if (rightSpaceScore >= leftSpaceScore) -dodgeRad else dodgeRad
            dribbleUntilMs = now + Random.nextLong(220L, 321L)

            val baseAngle = atan2(baseDy, baseDx)
            val evasiveAngle = baseAngle + dribbleAngleOffsetRad
            return TacticalCommand(
                hasDirection = true,
                moveDx = cos(evasiveAngle),
                moveDy = sin(evasiveAngle),
                label = if (rightSpaceScore >= leftSpaceScore) "DRIBBLE_RIGHT" else "DRIBBLE_LEFT"
            )
        }

        return TacticalCommand(
            hasDirection = true,
            moveDx = baseDx,
            moveDy = baseDy,
            label = "SPRINT_UPFIELD"
        )
    }

    private fun decideDefenseOrChase(
        ball: PointF,
        nearestAlly: PointF?,
        opponents: List<PointF>
    ): TacticalCommand {
        if (nearestAlly == null) {
            return TacticalCommand(true, 0f, -1f, label = "TRACK_BACK")
        }
        val dx = ball.x - nearestAlly.x
        val dy = ball.y - nearestAlly.y
        val d = hypot(dx, dy)

        val pressBtn = if (d < 0.22f && opponents.any { dist(it, ball) < 0.14f }) {
            ActionButton.B_LOW_PASS_PRESS
        } else {
            ActionButton.NONE
        }

        return TacticalCommand(
            hasDirection = true,
            moveDx = dx,
            moveDy = dy,
            actionButton = pressBtn,
            holdDurationMs = if (pressBtn != ActionButton.NONE) 160L else 0L,
            label = if (pressBtn != ActionButton.NONE) "PRESS_BALL (B)" else "CHASE_BALL"
        )
    }

    private fun evaluateSideSpace(player: PointF, opponents: List<PointF>, goRight: Boolean): Float {
        val probeX = if (goRight) player.x + 0.20f else player.x - 0.20f
        if (abs(probeX) > 0.88f) return -10f
        val probe = PointF(probeX, (player.y + 0.14f).coerceAtMost(0.98f))
        return opponents.minOfOrNull { dist(probe, it) } ?: 1.0f
    }

    private fun isUnmarked(ally: PointF, opponents: List<PointF>, radius: Float): Boolean {
        return opponents.none { dist(ally, it) < radius }
    }

    private fun findNearestFrontOpponent(player: PointF, opponents: List<PointF>, maxDist: Float): PointF? {
        return opponents
            .filter { it.y > player.y && dist(player, it) <= maxDist }
            .minByOrNull { dist(player, it) }
    }

    private fun isPassLineBlocked(from: PointF, to: PointF, opponents: List<PointF>, corridorWidth: Float): Boolean {
        val vx = to.x - from.x
        val vy = to.y - from.y
        val lenSq = vx * vx + vy * vy
        if (lenSq < 1e-5f) return false

        for (opp in opponents) {
            val t = (((opp.x - from.x) * vx + (opp.y - from.y) * vy) / lenSq)
            if (t in 0.1f..0.9f) {
                val projX = from.x + t * vx
                val projY = from.y + t * vy
                if (hypot(opp.x - projX, opp.y - projY) < corridorWidth) {
                    return true
                }
            }
        }
        return false
    }

    private fun findNearest(target: PointF, list: List<PointF>): PointF? {
        return list.minByOrNull { dist(target, it) }
    }

    private fun dist(a: PointF, b: PointF): Float {
        return hypot(a.x - b.x, a.y - b.y)
    }
}
