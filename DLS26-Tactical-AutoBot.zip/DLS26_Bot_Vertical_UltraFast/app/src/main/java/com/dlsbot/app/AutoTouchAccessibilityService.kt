package com.dlsbot.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class AutoTouchAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: AutoTouchAccessibilityService? = null

        private const val SNAP_FORWARD_DEG = 10.0
        private const val SNAP_CURRENT_DEG = 8.0
        private const val MAX_TURN_PER_STEP_DEG = 30.0
        private const val MICRO_JITTER_PX = 1.2f
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile private var targetHasDirection: Boolean = false
    @Volatile private var targetScreenAngleRad: Double = -PI / 2.0
    @Volatile private var pendingButton: ActionButton = ActionButton.NONE
    @Volatile private var pendingHoldMs: Long = 0L

    private var isLoopActive: Boolean = false
    private var isGestureInFlight: Boolean = false
    private var lastJoystickStroke: GestureDescription.StrokeDescription? = null
    private var currentScreenAngleRad: Double = -PI / 2.0
    private var currentJoyX: Float = 0f
    private var currentJoyY: Float = 0f

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Không cần xử lý event UI
    }

    override fun onInterrupt() {
        releaseJoystickImmediately()
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseJoystickImmediately()
        if (instance === this) instance = null
    }

    fun updateCommand(cmd: TacticalCommand) {
        if (!BotRuntimeState.canDispatchTouch()) {
            if (isLoopActive) {
                mainHandler.post { releaseJoystickImmediately() }
            }
            return
        }

        if (cmd.hasDirection && (abs(cmd.moveDx) > 1e-4f || abs(cmd.moveDy) > 1e-4f)) {
            targetScreenAngleRad = mapMinimapVectorToScreenAngle(cmd.moveDx, cmd.moveDy)
            targetHasDirection = true
        } else {
            targetHasDirection = false
        }

        if (cmd.actionButton != ActionButton.NONE && cmd.holdDurationMs > 0L) {
            pendingButton = cmd.actionButton
            pendingHoldMs = cmd.holdDurationMs
        }

        if (targetHasDirection && !isLoopActive) {
            mainHandler.post {
                if (BotRuntimeState.canDispatchTouch() && targetHasDirection && !isLoopActive) {
                    startContinuousJoystick()
                }
            }
        }
    }

    private fun mapMinimapVectorToScreenAngle(dx: Float, dy: Float): Double {
        val baseAngle = atan2((-dy).toDouble(), dx.toDouble())
        val rotRad = Math.toRadians(BotRuntimeState.joystickRotationDeg.toDouble())
        return normalizeAngle(baseAngle + rotRad)
    }

    private fun startContinuousJoystick() {
        if (!BotRuntimeState.canDispatchTouch() || isGestureInFlight) return

        val center = BotRuntimeState.joyCenter
        val radius = BotRuntimeState.joyRadius
        currentScreenAngleRad = targetScreenAngleRad

        val targetX = center.x + (cos(currentScreenAngleRad) * radius).toFloat()
        val targetY = center.y + (sin(currentScreenAngleRad) * radius).toFloat()

        val startPath = Path().apply {
            moveTo(center.x, center.y)
            lineTo(targetX, targetY)
        }
        val stepDuration = Random.nextLong(60L, 76L)
        val initialStroke = GestureDescription.StrokeDescription(startPath, 0L, stepDuration, true)

        currentJoyX = targetX
        currentJoyY = targetY
        lastJoystickStroke = initialStroke
        isLoopActive = true
        isGestureInFlight = true

        val gesture = GestureDescription.Builder().addStroke(initialStroke).build()
        val dispatched = dispatchGesture(gesture, gestureCallback, null)
        if (!dispatched) {
            resetStrokeState()
        }
    }

    private fun dispatchNextContinuousSegment() {
        if (!isLoopActive || isGestureInFlight) return

        val prevStroke = lastJoystickStroke
        if (prevStroke == null) {
            resetStrokeState()
            return
        }

        if (!BotRuntimeState.canDispatchTouch() || !targetHasDirection) {
            val endPath = Path().apply {
                moveTo(currentJoyX, currentJoyY)
                lineTo(currentJoyX, currentJoyY)
            }
            val endStroke = prevStroke.continueStroke(endPath, 0L, 20L, false)
            isGestureInFlight = true
            isLoopActive = false
            lastJoystickStroke = null
            dispatchGesture(GestureDescription.Builder().addStroke(endStroke).build(), object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    isGestureInFlight = false
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    isGestureInFlight = false
                }
            }, null)
            return
        }

        val forwardScreenAngle = mapMinimapVectorToScreenAngle(0f, 1f)
        var desiredAngle = targetScreenAngleRad

        if (abs(angleDiffDeg(desiredAngle, forwardScreenAngle)) <= SNAP_FORWARD_DEG) {
            desiredAngle = forwardScreenAngle
        }

        val diffFromCurrentDeg = angleDiffDeg(desiredAngle, currentScreenAngleRad)
        val nextAngle = if (abs(diffFromCurrentDeg) < SNAP_CURRENT_DEG) {
            currentScreenAngleRad
        } else {
            val clampedDeltaDeg = diffFromCurrentDeg.coerceIn(-MAX_TURN_PER_STEP_DEG, MAX_TURN_PER_STEP_DEG)
            normalizeAngle(currentScreenAngleRad + Math.toRadians(clampedDeltaDeg))
        }

        val center = BotRuntimeState.joyCenter
        val radius = BotRuntimeState.joyRadius
        val jitterX = (Random.nextFloat() * 2f - 1f) * MICRO_JITTER_PX
        val jitterY = (Random.nextFloat() * 2f - 1f) * MICRO_JITTER_PX

        val nextX = center.x + (cos(nextAngle) * radius).toFloat() + jitterX
        val nextY = center.y + (sin(nextAngle) * radius).toFloat() + jitterY

        val btnToPress = pendingButton
        val btnHoldMs = pendingHoldMs
        pendingButton = ActionButton.NONE
        pendingHoldMs = 0L

        val baseStepDuration = Random.nextLong(60L, 76L)
        val joyDuration = if (btnToPress != ActionButton.NONE) {
            maxOf(baseStepDuration, btnHoldMs)
        } else {
            baseStepDuration
        }

        val joyPath = Path().apply {
            moveTo(currentJoyX, currentJoyY)
            lineTo(nextX, nextY)
        }
        val nextJoyStroke = prevStroke.continueStroke(joyPath, 0L, joyDuration, true)

        val builder = GestureDescription.Builder().addStroke(nextJoyStroke)

        if (btnToPress != ActionButton.NONE) {
            val btnPoint = getButtonPoint(btnToPress)
            val bx = btnPoint.x + (Random.nextFloat() * 2f - 1f) * 2.5f
            val by = btnPoint.y + (Random.nextFloat() * 2f - 1f) * 2.5f
            val btnPath = Path().apply {
                moveTo(bx, by)
                lineTo(bx + 0.5f, by + 0.5f)
            }
            val btnStroke = GestureDescription.StrokeDescription(btnPath, 0L, btnHoldMs, false)
            builder.addStroke(btnStroke)
        }

        currentScreenAngleRad = nextAngle
        currentJoyX = nextX
        currentJoyY = nextY
        lastJoystickStroke = nextJoyStroke
        isGestureInFlight = true

        val dispatched = dispatchGesture(builder.build(), gestureCallback, null)
        if (!dispatched) {
            resetStrokeState()
        }
    }

    private val gestureCallback = object : GestureResultCallback() {
        override fun onCompleted(gestureDescription: GestureDescription?) {
            isGestureInFlight = false
            dispatchNextContinuousSegment()
        }

        override fun onCancelled(gestureDescription: GestureDescription?) {
            resetStrokeState()
        }
    }

    fun releaseJoystickImmediately() {
        mainHandler.post {
            if (!isLoopActive && lastJoystickStroke == null) return@post
            targetHasDirection = false
            if (!isGestureInFlight && lastJoystickStroke != null) {
                dispatchNextContinuousSegment()
            } else {
                isLoopActive = false
            }
        }
    }

    private fun resetStrokeState() {
        isLoopActive = false
        isGestureInFlight = false
        lastJoystickStroke = null
    }

    private fun getButtonPoint(button: ActionButton): PointF {
        return when (button) {
            ActionButton.A_SHOOT_TACKLE -> BotRuntimeState.btnA
            ActionButton.B_LOW_PASS_PRESS -> BotRuntimeState.btnB
            ActionButton.C_CROSS_SWITCH -> BotRuntimeState.btnC
            ActionButton.NONE -> BotRuntimeState.btnB
        }
    }

    private fun normalizeAngle(rad: Double): Double {
        var a = rad
        while (a > PI) a -= 2.0 * PI
        while (a < -PI) a += 2.0 * PI
        return a
    }

    private fun angleDiffDeg(targetRad: Double, currentRad: Double): Double {
        val diffRad = normalizeAngle(targetRad - currentRad)
        return Math.toDegrees(diffRad)
    }
}
