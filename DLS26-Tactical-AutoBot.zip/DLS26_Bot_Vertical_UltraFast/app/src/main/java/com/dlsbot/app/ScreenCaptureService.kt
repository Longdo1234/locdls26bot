package com.dlsbot.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Process
import org.opencv.core.CvType
import org.opencv.core.Mat

class ScreenCaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_WIDTH = "width"
        const val EXTRA_HEIGHT = "height"
        const val EXTRA_DENSITY = "density"

        private const val CHANNEL_ID = "dls_bot_capture_channel"
        private const val NOTIFICATION_ID = 1001
        private const val MIN_SCAN_INTERVAL_MS = 22L      // ~45 FPS max
        private const val DEBUG_DRAW_INTERVAL_MS = 66L    // ~15 FPS cho DebugOverlayView

        @Volatile var debugOverlayCallback: ((MinimapSnapshot, TacticalCommand) -> Unit)? = null
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var visionThread: HandlerThread? = null
    private var visionHandler: Handler? = null

    private val scanner = MinimapScanner()
    private val tacticalEngine = TacticalDecisionEngine()

    private var lastScanTimeMs: Long = 0L
    private var lastDebugDrawTimeMs: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        val width = intent?.getIntExtra(EXTRA_WIDTH, 1080) ?: 1080
        val height = intent?.getIntExtra(EXTRA_HEIGHT, 2400) ?: 2400
        val density = intent?.getIntExtra(EXTRA_DENSITY, 420) ?: 420

        if (resultCode != -1 && resultData != null) {
            startCapturePipeline(resultCode, resultData, width, height, density)
        }
        return START_STICKY
    }

    private fun startForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "DLS 26 Ultra-Fast Vision",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("DLS 26 Bot Vision đang chạy")
                .setContentText("Quét Minimap dọc tốc độ cao (30–45 FPS)")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("DLS 26 Bot Vision đang chạy")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .build()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startCapturePipeline(
        resultCode: Int,
        resultData: Intent,
        width: Int,
        height: Int,
        density: Int
    ) {
        stopCapturePipeline()

        visionThread = object : HandlerThread("DLS_Vision_Urgent") {
            override fun onLooperPrepared() {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
            }
        }.apply { start() }
        visionHandler = Handler(visionThread!!.looper)

        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).apply {
            setOnImageAvailableListener({ reader ->
                processLatestFrame(reader)
            }, visionHandler)
        }

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "DLS26_ScreenCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            visionHandler
        )
    }

    private fun processLatestFrame(reader: ImageReader) {
        val image: Image = reader.acquireLatestImage() ?: return
        try {
            val now = System.currentTimeMillis()
            if (now - lastScanTimeMs < MIN_SCAN_INTERVAL_MS) {
                return
            }
            lastScanTimeMs = now

            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val matWidth = image.width + rowPadding / pixelStride
            val matHeight = image.height

            // Wrap trực tiếp ByteBuffer vào Mat (không copy toàn màn hình)
            val fullMat = Mat(matHeight, matWidth, CvType.CV_8UC4, buffer)
            val snapshot = try {
                scanner.scan(fullMat, BotRuntimeState.minimapRect)
            } finally {
                fullMat.release()
            }

            // Tính toán chiến thuật
            val command = tacticalEngine.decide(snapshot)

            // Gửi lệnh cho AccessibilityService (bên trong đã khóa cứng canDispatchTouch())
            AutoTouchAccessibilityService.instance?.updateCommand(command)

            // Tách biệt luồng vẽ DebugOverlayView ở 15 FPS
            if (now - lastDebugDrawTimeMs >= DEBUG_DRAW_INTERVAL_MS) {
                lastDebugDrawTimeMs = now
                debugOverlayCallback?.invoke(snapshot, command)
            }
        } finally {
            image.close()
        }
    }

    private fun stopCapturePipeline() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        mediaProjection?.stop()
        mediaProjection = null
        visionThread?.quitSafely()
        visionThread = null
        visionHandler = null
    }

    override fun onDestroy() {
        super.onDestroy()
        stopCapturePipeline()
        scanner.release()
    }
}
