package com.dlsbot.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.util.AttributeSet
import android.view.View

class DebugOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    @Volatile private var latestSnapshot: MinimapSnapshot? = null
    @Volatile private var latestCommand: TacticalCommand? = null

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.CYAN
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val allyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED
        style = Paint.Style.FILL
    }

    private val oppPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW
        style = Paint.Style.FILL
    }

    private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val vectorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 28f
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }

    fun updateDebugData(snapshot: MinimapSnapshot, command: TacticalCommand) {
        latestSnapshot = snapshot
        latestCommand = command
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val rect = BotRuntimeState.minimapRect
        canvas.drawRect(rect, borderPaint)

        val snap = latestSnapshot ?: return
        val cmd = latestCommand

        for (p in snap.allies) {
            val pt = mapNormToRect(p, snap.attackingUp)
            canvas.drawCircle(pt.x, pt.y, 7f, allyPaint)
        }

        for (p in snap.opponents) {
            val pt = mapNormToRect(p, snap.attackingUp)
            canvas.drawCircle(pt.x, pt.y, 7f, oppPaint)
        }

        snap.ball?.let { b ->
            val pt = mapNormToRect(b, snap.attackingUp)
            canvas.drawCircle(pt.x, pt.y, 8f, ballPaint)
        }

        if (cmd != null && cmd.hasDirection) {
            val cx = rect.exactCenterX()
            val cy = rect.exactCenterY()
            val scale = 45f
            val endX = cx + cmd.moveDx * scale
            val endY = cy - cmd.moveDy * scale
            canvas.drawLine(cx, cy, endX, endY, vectorPaint)
        }

        val dirText = if (snap.attackingUp) "UP ↑" else "DOWN ↓"
        val info = "Scan: ${snap.scanLatencyMs}ms | Dir: $dirText | ${cmd?.label ?: "IDLE"}"
        canvas.drawText(info, rect.left.toFloat(), (rect.bottom + 34).toFloat(), textPaint)
    }

    private fun mapNormToRect(norm: PointF, attackingUp: Boolean): PointF {
        val rect = BotRuntimeState.minimapRect
        val rawX = (norm.x + 1f) * 0.5f
        val rawY = if (attackingUp) (1f - norm.y) * 0.5f else (norm.y + 1f) * 0.5f
        return PointF(
            rect.left + rawX * rect.width(),
            rect.top + rawY * rect.height()
        )
    }
}
